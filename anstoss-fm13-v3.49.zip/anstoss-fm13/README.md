# Anstoß Mobile Pro - FM13

Modulare Quellcode-Struktur: `index.html` + `css/styles.css` + `js/*.js`.

## Spielen

**Online:** https://mrcrapsle.github.io/FuMan/ — wird bei jedem Push auf `main`
automatisch neu gebaut und veröffentlicht (siehe `deploy`-Job in
`.github/workflows/build-test.yml`), aber nur wenn die Testsuite auf demselben
Commit grün war. Läuft auf jedem Gerät, Spielstände werden im Browser gespeichert.

**Offline:** `dist/anstoss-fm13-standalone.html` ist das komplette Spiel in einer
Datei. Auf Android in einem echten Browser öffnen (Chrome), nicht in der
Dateivorschau des Dateimanagers - die blockiert den lokalen Speicher.

## Bauen
python3 build.py
→ erzeugt dist/anstoss-fm13-standalone.html

## Lokal spielen/entwickeln (empfohlen)
npm run serve            # oder: python3 server.py
→ baut dist/ und startet einen lokalen Server auf Port 8000. Ausgegeben wird
auch die Adresse im lokalen Netz - damit lässt sich das Spiel direkt auf dem
Handy im Browser öffnen, ohne die HTML-Datei zu kopieren.

Das ist nicht nur bequemer: über `file://` blockieren manche Android-WebViews
den Zugriff auf localStorage komplett (genau daran scheiterte das Speichern in
der Dateivorschau, siehe `safeLocalSet()` in index.html). Über `http://` tritt
das Problem nicht auf.

Erreichbar sind:
- `/` — die modulare Fassung (index.html + css/ + js/), Änderungen sind nach
  einem Reload sofort sichtbar
- `/spiel` — die gebaute Standalone-Datei; sie wird automatisch neu gebaut,
  sobald eine Quelldatei neuer ist als das Build-Ergebnis

Optionen: `--port 5000` für einen anderen Port, `--no-build` zum Starten ohne
Neubau.

## Testen
python3 build.py
cd tests
npm install
npm test
→ prüft die gebaute dist/anstoss-fm13-standalone.html per Playwright gegen
die Testsuite in `tests/run-tests.js`.

## Linten
npm install
npm run lint
→ lintet alle js/*.js-Module + die inline <script>-Blöcke aus index.html
als EIN zusammengefügter globaler Scope (siehe build.py --lint-bundle),
damit ESLint keine falschen "undefined"-Meldungen für Funktionen aus
anderen Dateien wirft.

## Minifizieren (optional)
python3 build.py
npm install
npm run minify
→ erzeugt zusätzlich dist/anstoss-fm13-standalone.min.html (~30% kleiner) -
praktisch zum Weitergeben/Teilen. Die normale, lesbare Datei bleibt für
Entwicklung/Tests unverändert bestehen. mangle ist bewusst deaktiviert, da
Buttons ihre Funktionen über onclick="..." als HTML-String aufrufen, den ein
Minifizierer nicht sieht.

## Managerbüro (Startbildschirm)

`js/office.js` + der CSS-Block "MANAGERBÜRO" in `css/styles.css` bauen den
Point-and-Click-Startbildschirm: eine begehbare Bürokulisse aus fünf
CSS-3D-Ebenen mit elf anklickbaren Objekten, die in die jeweiligen
Spielbereiche führen. Das Büro liegt als Vollbild-Ebene (`position:fixed`,
z-index 940) über der übrigen Oberfläche und ist über den Knopf oben im
Dashboard jederzeit wieder erreichbar; zurück geht es über "Zum Dashboard"
in der Leiste oben rechts.

Die Szene wird immer für eine feste Logikgröße (900x560) komponiert und als
Ganzes skaliert - sonst fiele auf schmalen Geräten der komplette
Seitenwand-Bereich (Tür, Taktiktafel, Tresor, Aktenschrank) aus dem
Sichtkegel. Bleibt dabei viel Platz über/unter der Kulisse (Hochformat),
erscheint darunter automatisch eine beschriftete Schnellauswahl derselben
Ziele, weil die Objekte dort klein zum Antippen sind.

**Der Raum spiegelt den Spielstand.** Der Blick aus dem Fenster wird von
`getOfficeOutlook()` aus echtem Zustand abgeleitet: Steht ein Heimspiel oder ein
Pokal-/Europapokaltermin an UND ist eine Flutlichtanlage gebaut
(`stadium.flutlicht`), brennt draußen das Flutlicht und es ist Abend - ohne
Anlage wird bei Tageslicht gespielt, der Ausbau verändert also sichtbar die
Kulisse. Dazu kommt das aktuelle Wetter aus `js/weather.js` (Regen, Schnee,
Sturm, Hitze). Das gerahmte Vereinswappen an der Wand nutzt exakt dieselben
Daten wie das Header-Logo (`applyClubCrest()` in `crest.js`) samt Muster-Badge,
Maskottchen und Sponsorenring.

Bewusst **kein Three.js/WebGL** - das Spiel muss eine einzige, offline
lauffähige HTML-Datei bleiben; eine 3D-Bibliothek wären ~600 KB Fremdcode
plus WebGL-Zwang im Android-WebView. Dieselbe CSS-3D-Technik nutzen
Taktiktafel und Stadionschüssel bereits.

**Klicks lösen sich NICHT über die native Trefferprüfung des Browsers auf.**
`officeHotspotAtPoint()` vergleicht stattdessen selbst die projizierten
Bildschirmrechtecke (`getBoundingClientRect()`), und ein einzelner
Click-/Mousemove-Handler am Viewport verteilt daraus Klick, Hervorhebung und
Satzzeile. Grund: für 3D-transformierte Elemente ist die native Hit-Detection
je nach Chromium-Version unzuverlässig - in einer neueren Version waren 9 von
10 damaligen Objekten nicht mehr anklickbar, obwohl das Bild unverändert aussah
(in der CI aufgefallen, lokal nicht reproduzierbar). Deshalb auch kein
CSS-`:hover` für die Hervorhebung, sondern eine aus JS gesetzte Klasse.

**Zwei weitere Fallstricke**, die hier real zugeschlagen haben und von außen
unsichtbar sind (das Bild bleibt korrekt, nur die Geometrie wandert weg):

1. `filter` und `opacity` sind "grouping properties": auf einer
   3D-positionierten Ebene erzwingen sie `transform-style: flat` und
   klappen sie in die Elternebene. Zum Abdunkeln/Hervorheben deshalb
   Hintergrundschichten bzw. `box-shadow` verwenden.
2. Laufende `transform`-Animationen befördern das Element auf eine eigene
   Compositing-Ebene. Animationen im Raum daher ohne `transform`
   (z.B. pulsendes `box-shadow`).

`testManagerOffice` in `tests/run-tests.js` prüft, dass jeder Hotspot an
seinem Mittelpunkt korrekt aufgelöst wird, und klickt per Koordinate
(`mouse.click`) statt per Selektor - `page.click(selektor)` prüft intern
ebenfalls die native Trefferfläche.

## Start der Seite: die Ladeanzeige

Die fertige Datei ist über ein Megabyte groß und bringt ihren gesamten Code
inline mit. Bis der geparst ist, vergeht auf dem Handy spürbar Zeit - und in
diesem Fenster war das Dashboard bereits sichtbar UND bedienbar, denn es war
der einzige Screen ohne `display:none` im Markup. Wer dort tippte, rief eine
Funktion auf, die es noch nicht gab (`showScreen is not defined`, aus einem
echten Fehlerprotokoll vom Live-Spiel).

`#app-loading` liegt deshalb von Anfang an über allem und wird am Ende von
`window.onload` in einem **`finally`** entfernt - auf jedem Weg, auch wenn der
Start scheitert, sonst wäre das Spiel darunter geladen, aber unbedienbar.
Scheitert selbst der Fallback-Boot, wird die Fehlermeldung in die Ladeebene
geschrieben statt per `alert()` (das wäre in genau den WebViews unsichtbar, in
denen dieser Fall am ehesten eintritt).

Der Test dazu lädt die Seite mit **abgeschaltetem JavaScript** - das ist exakt
der Zustand vor dem Ausführen der Skripte - und prüft, dass kein Knopf
anklickbar ist.

## Rückmeldungen an den Spieler: keine nativen Dialoge

**Tragende Projektregel, durch einen Test abgesichert:** Im ausführbaren Code
steht kein `alert()` und kein `confirm()` mehr. Native Dialoge werden in
manchen Android-WebViews unterdrückt - der Klick bleibt dann kommentarlos
wirkungslos, und genau das hat sich mehrfach als Fehlerursache herausgestellt
(Fabrikbau, Transfers). Drei Wege stehen zur Verfügung:

* `showToast(text, typ, dauer)` - kurze Rückmeldung, vor allem Fehlermeldungen.
  Die nennen konkrete Zahlen ("250.000 € nötig, 80.000 € verfügbar") statt nur
  "reicht nicht aus".
* `showNotice(titel, text, {typ, knopf, danach})` (`js/utils.js`) - ein
  Meldungsfenster in der Seite für WICHTIGE Ereignisse (Aufstieg, Abstieg,
  Entlassung, Skandale, Pokalsieg). Anders als `alert()` blockiert es nicht,
  deshalb sammelt es mehrere Meldungen in einer Schlange und zeigt sie
  nacheinander - während einer durchsimulierten Saison kommen leicht mehrere
  zusammen. `danach` läuft erst NACH dem Bestätigen: daran hängt zum Beispiel
  der Neustart bei einer Entlassung, der vorher direkt nach dem `alert()`
  passierte und den Verein bei unterdrücktem Dialog wortlos verschwinden ließ.
* `requireConfirm(btn, frage)` - Zwei-Klick-Bestätigung statt `confirm()`.

**Fallstrick, teuer gelernt:** `showNotice()` blockiert nicht. Wo vorher ein
`alert()` stand, lief der Code danach also erst nach dem Klick weiter - jetzt
läuft er sofort weiter. Bei der Entlassung war das heikel: Der native Dialog
stoppte die Simulationsschleife, und der direkt folgende Reload beendete alles.
Ohne Gegenmaßnahme simulierte das Spiel munter weiter, für einen Verein, den man
gar nicht mehr betreut - und die wichtigste Meldung überhaupt verschwand hinter
den Spieltagsmeldungen. Deshalb: `game.sackPending` stoppt `simulateMatchdays()`
und `startMatchdayFlow()`, und die Meldung nutzt `sofort: true`, das sie an den
Anfang der Warteschlange stellt. Wer eine weitere blockierende Stelle durch
`showNotice()` ersetzt, muss prüfen, was danach weiterläuft.

## Büro-Ereignisse (js/office-events.js)

Das Managerbüro war reine Kulisse mit Navigation - alles, was im Verein
passierte, landete als Text im Postfach. Jetzt sitzt gelegentlich jemand auf
dem **Besucherstuhl** vor dem Schreibtisch: Spielerberater, Fan-Delegation,
Lokalreporter, Platzwart, Nachwuchstrainer, Steuerprüferin,
Sponsorenvertreterin, Vereinsältester. Jede Begegnung hat mehrere Antworten mit
unterschiedlichen Folgen - bewusst ohne eine Option, die immer richtig ist
(Fans gegen Vorstand, Geld gegen Stimmung, Medienimage gegen Ruhe).

Mechanik: `rollOfficeEvent()` hängt an `processPostMatchRoutine()`, es wartet
immer höchstens einer. Das Gespräch läuft über ein Overlay **innerhalb** des
Büros (`#office-event-panel`), man verlässt den Raum also nicht. Geldwirkungen
laufen unter dem Buchungskontext "Bürotermin" und erscheinen damit im
Kontoauszug. Wer sich nicht kümmert, wird nicht blockiert: nach
`OFFICE_EVENT_TIMEOUT` Spieltagen gibt der Besucher auf.

Zwei Fallstricke beim Zeichnen der Figur, beide teuer gelernt:

* Die Malreihenfolge im Hotspot-HTML ist die Tiefenreihenfolge. Standen Lehne
  und Gestell hinter der Figur im Markup, übermalten sie den Besucher und man
  sah nur den Kopf.
* Auf schmalen Geräten ist die Schnellauswahl unter der Kulisse der eigentliche
  Bedienweg. Sie filtert auf Objekte mit Ziel-Screen - ein wartender Besucher
  wäre dort gar nicht aufgetaucht und nur über den kleinen Stuhl erreichbar
  gewesen. `renderOfficeQuickNav()` stellt ihm deshalb einen eigenen Eintrag
  voran.

## Sponsoren & Finanzen

**Bandenwerbung** hängt an den echten Stadionbereichen (`stadium.blocks`): jeder
Block hat eigene Bandenplätze, deren Anzahl mit seiner Kapazität wächst - jeder
Stadionausbau schafft also zusätzliche Werbeflächen. Was eine Bande einbringt,
ergibt sich aus Ligastufe x Sichtbarkeit des Bereichs (`BANDEN_AREA_META` in
`js/sponsors.js` - Haupttribüne und Gegengerade liegen im Kameraschwenk, die
Presse-Tribüne im Rücken der Interviews, VIP-Logen erreichen zahlungskräftiges
Publikum) x Größe des Blocks. Banden aus älteren Spielständen ohne
Bereichszuordnung werden beim Laden automatisch auf freie Plätze verteilt.

**Steuern**: Auf jede Spieltagseinnahme (Tickets, Fanartikel, Sponsoren) wird
eine Abgabe fällig (12%, mit Steuerberater 7%, siehe `getTaxRate()` in
`js/finances.js`, verbucht in `applyMatchdayFinances`). Der Steuerberater kostet
dafür ein laufendes Honorar, das mit der Ligastufe steigt - unten trägt er sich
gerade so, oben lohnt er sich deutlich. Zusätzlich mildert er die
Insolvenz-Eskalationen ab (`checkInsolvencyRisk()`).

**Buchungsjournal & Kontoauszug** (Finanzen-Screen, Reiter unter der GuV):

* `game.financeLedger` - `applyMatchdayFinances()` schreibt zu JEDEM Spieltag
  einen echten Buchungssatz mit allen Einzelposten (Ticket, Fanartikel, jeder
  Sponsor einzeln, Gehälter, Unterhalt, Ordnerdienst, Steuern). Kosten, die erst
  NACH `applyMatchdayFinances()` anfallen, tragen sich über
  `bucheInSpieltagsjournal(label, betrag)` nach.
* `game.kontoauszug` - alle übrigen Kontobewegungen. **Achtung, tragende
  Konstruktion:** Geld wird an über 150 Stellen direkt über `game.money`
  verrechnet. Statt jede davon einzeln zu protokollieren, macht
  `installKontoauszug()` (Ende von `js/finances.js`) aus `game.money` eine
  Accessor-Property. Jede Zuweisung läuft damit durch einen Kontrollpunkt.
  Folgen, die man kennen muss:
  * Beim Laden eines Spielstands (`Object.assign(game, p.game)`) muss die
    Protokollierung über `kontoauszugPausieren()` / `kontoauszugFortsetzen()`
    ausgesetzt werden, sonst erscheint der geladene Kontostand als Phantombuchung.
  * Die Beschriftung einer Buchung kommt aus `aktiverScreen` (gesetzt in
    `showScreen()`) oder aus einem explizit gesetzten `setzeBuchungskontext()`.
    Neue Screens gehören deshalb in `SCREEN_BUCHUNGS_LABELS`.
  * Spieltagsbuchungen laufen unter `SPIELTAG_KONTEXT` und werden bewusst NICHT
    in den Kontoauszug geschrieben - sie stehen vollständig im Journal.

**Betriebskosten des Stadions**: Nicht benötigte Ränge gelten als stillgelegt und
kosten nur 30 % Unterhalt (`getStadiumBaseMaintenance()` in `js/stadium.js`,
genutzt von `applyMatchdayFinances()`, der GuV-Prognose und dem Dashboard -
die Formel steht bewusst nur an EINER Stelle). Die genutzte Kapazität ergibt
sich aus dem Zuschauerschnitt der letzten fünf Heimspiele plus 15 % Reserve,
mindestens aber einem Fünftel des Stadions. Der Rabatt verschwindet von allein,
sobald der Verein das Stadion füllt.

**Gehälter im Amateurbereich**: Der Marktwert ist bis Stärke 44 konstant
15.000 €. Mit dem früheren Pauschalsockel von 300 € kostete dadurch JEDER
Spieler dort exakt 400 € pro Spieltag - über eine Saison fast so viel wie sein
gesamter Marktwert. `calculatePlayerWage()` staffelt unten jetzt nach Stärke
(`60 + str * 3 + Marktwert * 0.004`); ab Stärke 59 ist die Formel unverändert.

**Tragende Regel, durch einen Test abgesichert:** Jeder Euro, der das Konto
erreicht oder verlässt, steht entweder im Buchungsjournal oder im Kontoauszug -
die Summe beider muss exakt der Kontostandsänderung entsprechen, und keine
Buchung darf als "Sonstige Buchung" liegenbleiben. Spieltagskosten, die erst
nach `applyMatchdayFinances()` anfallen, prüfen deshalb mit
`hatSpieltagsabrechnung()`, ob für diesen Spieltag überhaupt gespielt wurde: an
spielfreien Spieltagen läuft `processPostMatchRoutine()` ohne vorherige
Abrechnung, eine Buchung von dort landete weder im Journal noch im Auszug.

**Ordnerdienst**: Gemietete Ordner werden pro Heimspiel nach Bedarf gebucht
(~1 Ordner je 25 Zuschauer, gedeckelt durch die vorgehaltene Zahl, siehe
`getDeployedStewards()`); auswärts stellt der Gastgeber das Personal. Vorher
wurde an jedem Spieltag die volle vorgehaltene Zahl abgerechnet.

## Pokalsystem: Landespokal als Weg in den DFB-Pokal

Im echten deutschen Fußball qualifiziert man sich aus den unteren Ligen **nicht**
direkt für den DFB-Pokal. Ab der 3. Liga ist man automatisch dabei; darunter
führt der Weg ausschließlich über den Landespokal des eigenen Verbands. Genau
dieser Schritt fehlte - ein Sechstligist startete einfach im DFB-Pokal gegen
Bundesligisten.

`js/landescup.js` bildet das ab:

* `isQualifiedForDfbPokal()` - ab `DFB_POKAL_DIREKT_AB_LIGA` (Ligastufe 2,
  also der 3. Liga) automatisch, darunter nur mit `game.dfbPokalViaLandespokal`
  aus der Vorsaison. `initDynamicCup()` löst den Startplatz dabei ein: Er gilt
  für genau eine Saison.
* Der Landespokal läuft über vier Runden an den Spieltagen **6, 14, 22, 30** -
  bewusst versetzt zum DFB-Pokal (4, 12, 20, 28, 34), damit sich nichts beißt.
* Gegner kommen aus der eigenen und den benachbarten Spielklassen **derselben
  Region** (`buildLandesPokalTeams()`), passend zur regionalen Gliederung der
  Vereinsnamen ab der 4. Liga.
* Die Prämien liegen weit unter denen des DFB-Pokals und skalieren mit der
  Ligastufe. Ein Verbandspokal finanziert keine Saison - er öffnet eine Tür.

Der Wettbewerb heißt nach `landesPokal.region` (Standard: Sachsen, passend zum
Startverein in Leipzig); `LANDESVERBAENDE` listet die übrigen Verbände für eine
spätere Regionswahl.

## Vereins- und Spielernamen

Alle Namen sind **minimal verfremdet** - ein geänderter Buchstabe, ein entfernter
Umlaut, eine leicht verschobene Jahreszahl. So bleibt erkennbar, welcher echte
Verein gemeint ist, ohne die geschützte Original-Schreibweise zu verwenden.
Ein Test prüft, dass kein Name exakt einem Original entspricht.

`LEAGUE_CLUB_NAMES` in `js/entities.js` hält **je Spielklasse einen eigenen Pool**
mit 18 Vereinen (108 insgesamt, keiner doppelt). `generateTeamName(leagueLevel)`
bedient sich zuerst beim Pool der passenden Liga; ohne Ligaangabe (Pokalgegner,
Leihverein, permanenter Rivale) wird aus allen gezogen. Vorher wurden alle
bekannten Namen quer über alle sechs Ligen verteilt, sodass Bayern in der
Kreisklasse auftauchen konnte.

**Regionalität ab der 4. Liga**: Der deutsche Fußball ist unterhalb der 3. Liga
regional geteilt. Weil der Verein des Spielers in Leipzig sitzt, bilden die
unteren drei Ligen den Nordost-Strang ab (Regionalliga Nordost, NOFV-Oberliga
Süd, Landesliga Sachsen). Das erzeugt zwei Effekte, die auch im echten Fußball
zusammenhängen: kurze Auswärtsfahrten und echte Derbys gegen Nachbarvereine -
in Leipzig gleich mehrere.

Wer die Pyramide auf eine andere Region umstellen will (etwa West statt
Nordost), tauscht die Pools 3 bis 5 aus; der Rest des Spiels hängt nicht daran.

## Zuschauerzahlen

Zwei Grenzen wirken zusammen, und **beide** werden gebraucht:

* `LEAGUE_ATTENDANCE_CEILING` deckelt den **Anteil** der Kapazität, der überhaupt
  besetzt wird (Oberliga 6 %).
* `LEAGUE_MAX_ATTENDANCE` deckelt die **absolute Zahl** (Oberliga 2.800 bei
  voller Fan-Zufriedenheit), skaliert mit `game.fans`.

Die absolute Grenze fehlte lange, und das war ein echter Modellfehler: Die
Zuschauerzahl war ausschließlich ein Anteil der Kapazität, also brachte Bauen
immer mehr Zuschauer - unabhängig von der Liga. Ein auf 113.000 Plätze
ausgebautes Stadion erzeugte in der Oberliga über 10.000 Zuschauer im Ligaalltag
und fast 23.000 im Derby (genau so vom Spieler gemeldet). Das Interesse an einem
Verein hängt aber an seiner Liga und seinem Anhang, nicht an der Zahl der
gebauten Sitze.

Der Derby-/Pokalbonus wirkt auf die absolute Grenze **gedämpft**
(`1 + (boost - 1) * 0.6`): Ein Derby steigert das Interesse, aber der Anhang
eines Vereins verdoppelt sich nicht über Nacht - mit vollem Bonus wäre die
Grenze ausgerechnet bei den Spielen wirkungslos, für die sie gedacht ist.

`calculateMatchAttendance()` ist die einzige Stelle, an der eine Zuschauerzahl
entsteht. Vorher stand die Rechnung doppelt im Code (Anpfiff im Live-Spiel und
Spieltagsabrechnung) und musste von Hand synchron gehalten werden.

## Ligaökonomie & Startoptionen

**TV-Gelder in Raten**: Die kollektive TV-Ausschüttung war eine Einmalzahlung zum
Saisonende. In den oberen Ligen ist sie aber die grösste Einnahmequelle - ein
Erstligist stand dadurch die ganze Saison zweistellig im Minus und wurde erst am
letzten Spieltag schlagartig solvent. `getTvMoneyInstallment()`
(`js/media-rights.js`) zahlt jetzt jeden Spieltag ein Vierunddreissigstel des
Ligagrundbetrags aus, bewusst **platzierungsneutral** (zu Saisonbeginn steht die
Tabelle auf null, ein zufälliger erster Platz würde sonst die ganze Saison über
50 % mehr bringen). Der Tabellenplatz entscheidet vollständig über die
**Restausschüttung** am Saisonende: `max(0, Anspruch(Endplatz) − bereits gezahlt)`.

**Startoptionen**: Startkapital (`NEW_GAME_LEAGUE_MONEY_SCALE`) und
Stadiongrösse (`NEW_GAME_LEAGUE_STADIUM_SCALE`, beide in `js/save.js`) skalieren
mit der gewählten Startliga. Die 6. Liga bleibt dabei unverändert (Faktor 1), die
für sie ausbalancierte Wirtschaft ist also nicht betroffen.
`scaleStadiumForLeague()` skaliert die Kapazität jedes Blocks einzeln -
`stadium.total` ist ein Getter über die Blöcke und darf nicht gesetzt werden.

**Startkader**: `generateSquadForLevel()` streute bis zu 8 Punkte über das
Ligamittel und erzeugte bei einem Erstliga-Start zwei Weltklassespieler mit
Stärke 96/97, die allein 43 % der Gehaltssumme verschlangen. Ein frisch
übernommener Klub ist ein Liga-Durchschnittsteam - die Obergrenze liegt jetzt
bei `base + 3`.

## Europapokal (js/europe.js)

**Teilnehmerfeld**: Früher bekam jeder der acht Teilnehmer pauschal Stärke
84-89. Das wurde nie gegen die tatsächlich erreichbare Teamstärke geprüft -
nachgemessen über 20 simulierte Saisons erreichte ein Erstliga-Meister NIE die
K.o.-Runde (18-mal Gruppenletzter), womit Halbfinale, Finale und der
25-Millionen-Titel toter Inhalt waren. Das Feld ist jetzt gestaffelt
(`FELD_STAFFELUNG`, zwei Schwergewichte, dann abfallend) und an das eigene
Kaderniveau gekoppelt.

**Wichtig dabei**: Bezugsgröße ist der reine **Kaderschnitt**, nicht
`calcTeamStrength()`. Letzteres schwankt stark mit Fitness, Moral und Form -
die Auslosung läuft zum Saisonstart, wo der frische Kader dort rund 97 meldet,
während derselbe Kader ab Spieltag 20 nur noch etwa 74 erreicht. Das Feld war
also am nie wieder erreichten Bestwert ausgerichtet. Der Abschlag von sechs
Punkten in `initEuropeCup()` bildet diesen Formverlust über die Saison ab.
Gemessen über 14 unabhängige Saisons landet ein Erstligist damit 1× auf Platz 1,
4× auf Platz 2, 5× auf Platz 3 und 4× auf Platz 4.

**Startprämie**: Es gab ausschließlich Siegprämien - wer sich qualifizierte und
in der Gruppe nichts holte, ging völlig leer aus. Die UEFA-Startprämie ist im
echten Wettbewerb die größte Einzelzahlung und wird jetzt zum ersten
Gruppenspieltag fällig, skaliert mit der Ligastufe.

## Zweite Mannschaft

Die Reserve hat einen **eigenen, kleinen Trainerstab** (`secondTeamStaff` in
`js/state.js`), unabhängig vom Profipersonal und mit eigenen Gehältern, die im
Buchungsjournal als Posten "Reserve-Trainerstab" stehen. Jede Rolle hat eine
echte Wirkung: Cheftrainer (+2 Teamstärke in der Liga-Simulation), Co-Trainer
(stellt automatisch auf), Physiotherapeut (Fitnessbilanz), Talentspäher
(besserer Amateurmarkt), Nachwuchs-Koordinator (U23 entwickeln sich weiter).

`tickSecondTeamRoutine()` hängt an `processPostMatchRoutine()` und läuft
deshalb in allen drei Spieltag-Pfaden mit, auch beim Durchsimulieren. Ohne
Personal schwächelt die Reserve langsam (Fitness-Boden 60 %), wird aber nie
unbrauchbar. Jugendspieler lassen sich wahlweise in den Profikader oder über
`promoteYouthToSecondTeam()` erst in die Reserve hochziehen.

## Trainingsstab-Automatik (Premium)

`js/training.js`: Das Fähigkeitstraining verlangte bei jedem Durchgang drei
manuelle Auswahlschritte. `autoPickSkillTraining()` (60 Punkte) füllt die
Auswahl einmalig optimal aus, `activateTrainingAutopilot()` (500 Punkte,
10 Spieltage) überlässt die Förderplanung komplett dem Stab.
`runTrainingAutopilotTick()` hängt ebenfalls an `processPostMatchRoutine()`,
startet höchstens drei Programme parallel und bucht den Verein nie ins Minus.
Die Trainingsgebühr zahlt weiterhin das Vereinskonto - Premium kauft die
Automatik, nicht das Training.

## Sprache (DE/EN)

Wörterbuch-basierter Sprachumschalter in `js/i18n.js` (Funktion `t(key)`,
Umschaltknopf 🌐 DE/EN im Header). Deutsch ist die Quelle der Wahrheit -
fehlt ein Übersetzungs-Key für Englisch, fällt `t()` automatisch auf den
deutschen Text zurück statt auf einen leeren/kaputten String.

**Aktueller Umfang:** Header, Seitenmenü und Tutorial sind vollständig
übersetzt. Die riesige Menge an Bildschirm-Inhalten (Kader, Transfermarkt,
Finanzen, Stadion, ...) folgt schrittweise in weiteren Ausbaustufen und
bleibt bis dahin auch bei gewählter Sprache "Englisch" auf Deutsch (dank
des Fallbacks kein Fehler, nur noch nicht übersetzter Text).
