
    // ==========================================
    // VEREINSIDENTITÄT: FREIE UMBENENNUNG
    // ==========================================
    // Der Klubname war bisher an ~120 Stellen im Code hart als "1.FC Moritz Leipzig"
    // verankert - jetzt läuft jeder dieser Vergleiche über game.clubName, wodurch eine
    // echte, jederzeit mögliche Umbenennung sicher wird: die Liga-Tabellenzeile, alle
    // Rivalen-/Freundschafts-Querverweise anderer Vereine auf uns UND (sofern noch nicht
    // eigenständig umbenannt) die zweite Mannschaft ziehen automatisch mit um.
    function renameClub(newName) {
        // Sicherheit: der Vereinsname landet an über einem Dutzend Stellen ungeprüft in
        // innerHTML-Templates (Tutorial-Titel, Liga-Tabelle, Speicherstand-Anzeige, ...) -
        // <, >, & und " werden entfernt, damit weder das Markup zerschossen noch beliebiges
        // HTML/JS über prompt() eingeschleust werden kann. Ein Vereinsname braucht diese
        // Zeichen ohnehin nicht; Umlaute, Ziffern, Punkte etc. bleiben unangetastet.
        newName = (newName || '').replace(/[<>&"]/g, '').trim().slice(0, 40);
        if (!newName || newName === game.clubName) return;
        let oldName = game.clubName;
        game.clubName = newName;

        for (let l = 0; l < NUM_LEAGUES; l++) {
            let row = leaguesData[l]?.find(t => t.name === oldName);
            if (row) { row.name = newName; break; }
        }
        if (game.secondTeam && game.secondTeam.name === `${oldName} II`) {
            let stOldName = game.secondTeam.name;
            game.secondTeam.name = `${newName} II`;
            for (let l = 0; l < NUM_LEAGUES; l++) {
                let row = leaguesData[l]?.find(t => t.name === stOldName);
                if (row) { row.name = game.secondTeam.name; break; }
            }
        }
        leaguesData.forEach(table => table.forEach(t => {
            if (t.friendName === oldName) t.friendName = newName;
        }));

        applyClubCrest();
        if (typeof renderSaveSlotsUI === 'function') renderSaveSlotsUI();
        updateUI();
        showToast(`✅ Verein umbenannt: ${newName}`, 'success');
    }
    // Eingabefeld im Spiel statt prompt(): native Dialoge unterdrücken viele Android-WebViews
    // stillschweigend - der Knopf tat dort gar nichts.
    function promptRenameClub() {
        let box = document.getElementById('club-rename-box');
        if (!box) return;
        if (box.innerHTML) { box.innerHTML = ''; return; }
        box.innerHTML = `<div class="box" style="display:flex; gap:6px; align-items:center;">
            <input type="text" id="club-rename-input" class="input-inline" maxlength="40" style="flex:1;" value="${game.clubName}">
            <button onclick="confirmRenameClub()" class="btn-action" style="width:auto; font-size:10px;">Übernehmen</button>
        </div>`;
    }
    function confirmRenameClub() {
        let input = document.getElementById('club-rename-input');
        let alt = game.clubName;
        renameClub(input ? input.value : '');
        if (game.clubName === alt) { showToast('Bitte einen neuen, gültigen Namen eingeben.', 'error'); return; }
        document.getElementById('club-rename-box').innerHTML = '';
        showToast(`✏️ Der Verein heißt jetzt ${game.clubName}.`, 'success');
    }

    // ==========================================
    // VEREINSWECHSEL: ZU EINEM BESTEHENDEN VEREIN DER PYRAMIDE WECHSELN
    // ==========================================
    // Echte Karriere-Mobilität statt nur Umbenennung: übernimmt eine bestehende KI-
    // Vereinszeile (Name + aktuelles Liganiveau + Tabellenstand) aus der jetzt persistenten
    // Liga-Pyramide (siehe advanceLeaguesToNewSeason() in leagues.js). Der alte Verein
    // bleibt unter seinem alten Namen als ganz normaler KI-Klub bestehen - man führt ihn nur
    // nicht mehr selbst. WICHTIGE EINSCHRÄNKUNG: KI-Vereine haben in leaguesData keinen
    // echten Kader (nur Name+Stärke+Tabellenstand) - "übernehmen" heißt daher einen frischen,
    // zum neuen Liganiveau passenden Kader zu bekommen, keinen echten Spielerbestand zu
    // erben. Stadion/Campus/Personal/Fans bleiben bewusst unverändert (reisen als deine
    // eigenen Investitionen mit dir mit) - nur Kader und Transfer-/Gehaltsbudget werden neu
    // auf das Zielniveau kalibriert; Karriere-Level, Trophäen und Vereinskonto bleiben erhalten.
    function switchToClub(targetName) {
        let targetLevel = -1;
        for (let l = 0; l < NUM_LEAGUES; l++) {
            if (leaguesData[l]?.some(t => t.name === targetName)) { targetLevel = l; break; }
        }
        if (targetLevel === -1) return false;

        game.clubName = targetName;
        game.leagueLevel = targetLevel;
        squad = generateSquadForLevel(targetLevel);
        game.captainId = squad[8].id;
        game.penaltyTakerId = squad[14].id;
        game.freeKickTakerId = squad[9].id;
        game.cornerTakerId = squad[9].id;
        autoLineup();

        // Budgets neu kalibrieren wie beim Saisonwechsel (concludeSeasonAndAdvance), aber
        // ohne Platzierungsbonus/-malus, da noch keine Saison beim neuen Verein gespielt wurde.
        let leagueFactor = (NUM_LEAGUES - targetLevel) / NUM_LEAGUES;
        game.transferBudget = Math.round(2500000 * (1 + leagueFactor * 2.5));
        game.wageBudget = getLeagueWageBudget(targetLevel);

        refreshTransferMarket();
        applyClubCrest();
        updateUI();
        return true;
    }

    let clubSwitchCandidates = null;
    function showClubSwitchOptions() {
        let excluded = [game.clubName, game.secondTeam.name];
        let pool = leaguesData.flatMap((table, l) => table.filter(t => !excluded.includes(t.name)).map(t => ({ team: t, level: l })));
        // Bevorzugt Vereine nahe am aktuellen Liganiveau (±1) - ein Sprung von der
        // Kreisklasse direkt in die Bundesliga wäre keine plausible Option.
        let nearLevel = pool.filter(p => Math.abs(p.level - game.leagueLevel) <= 1);
        let candidatePool = nearLevel.length >= 3 ? nearLevel : pool;
        clubSwitchCandidates = [...candidatePool].sort(() => Math.random() - 0.5).slice(0, 3)
            .map(p => ({ name: p.team.name, level: p.level, strength: p.team.strength }));
        renderClubSwitchOptions();
    }
    function renderClubSwitchOptions() {
        let box = document.getElementById('club-switch-box');
        if (!box) return;
        if (!clubSwitchCandidates) { box.innerHTML = ''; return; }
        box.innerHTML = `
            <div style="font-size:10px; color:var(--danger); margin:8px 0 4px;">⚠️ Ein Vereinswechsel ersetzt deinen kompletten Kader durch einen frischen, zum neuen Liganiveau passenden Kader. Karriere-Level, Trophäen und Vereinskonto bleiben erhalten.</div>
            ${clubSwitchCandidates.map(c => `
                <div class="box" style="display:flex; justify-content:space-between; align-items:center; margin-bottom:4px;">
                    <span>${c.name} <span style="color:var(--text-muted); font-size:9px;">(${leagueNames[c.level]})</span></span>
                    <button onclick="confirmClubSwitch('${c.name.replace(/'/g, "\\'")}', this)" data-confirming="false" class="btn-secondary" style="width:auto; padding:4px 10px; font-size:10px;">Übernehmen</button>
                </div>
            `).join('')}
            <button onclick="clubSwitchCandidates = null; renderClubSwitchOptions();" class="btn-secondary" style="margin-top:4px; font-size:10px;">Abbrechen</button>
        `;
    }
    function confirmClubSwitch(targetName, btn) {
        if (btn && btn.dataset.confirming !== 'true') {
            btn.dataset.confirming = 'true';
            btn.innerText = 'Wirklich? Kader weg!';
            setTimeout(() => { if (btn.isConnected) { btn.dataset.confirming = 'false'; btn.innerText = 'Übernehmen'; } }, 4000);
            return;
        }
        if (switchToClub(targetName)) {
            clubSwitchCandidates = null;
            renderClubSwitchOptions();
            showToast(`🔄 Wechsel vollzogen: jetzt Manager von ${targetName}!`, 'success');
        }
    }

    // ==========================================
    // KARRIERE-RÜCKBLICK & RUHESTAND
    // ==========================================
    function renderCareerSummary() {
        let box = document.getElementById('career-summary-box');
        if (!box) return;
        let bestWin = rivalryRecord.biggestWin;
        box.innerHTML = `
            <div class="modal-field-grid" style="grid-template-columns: 1fr 1fr;">
                <span class="label">Manager-Level:</span><span class="val">${managerRPG.level} (${managerRPG.xp} XP)</span>
                <span class="label">Saison:</span><span class="val">${game.season}</span>
                <span class="label">Aktuelle Liga:</span><span class="val">${leagueNames[game.leagueLevel]}</span>
                <span class="label">Trophäen gesamt:</span><span class="val">${(game.trophies || []).length}</span>
                <span class="label">Karriere-Stationen:</span><span class="val">${(game.careerStations || []).length ? game.careerStations.map(st => `${st.from} → ${st.to} (S${st.season})`).join(', ') : 'nur dieser Verein'}</span>
                <span class="label">Szenarien:</span><span class="val">${(game.scenarioResults || []).length ? game.scenarioResults.map(r => `${r.title} ${r.ok ? '⭐'.repeat(r.stars) : '❌'} (S${r.season})`).join(', ') : 'keine'}</span>
                <span class="label">Schon entlassen:</span><span class="val">${game.timesSacked || 0}×</span>
                <span class="label">Derby-Bilanz:</span><span class="val">${rivalryRecord.wins}S ${rivalryRecord.draws}U ${rivalryRecord.losses}N</span>
                <span class="label">Höchster Derbysieg:</span><span class="val">${bestWin ? `${bestWin.ourGoals}:${bestWin.oppGoals} (Saison ${bestWin.season})` : '-'}</span>
                <span class="label">Zweite Mannschaft:</span><span class="val">${game.secondTeam.isActive ? 'Aktiv' : 'Nicht gegründet'}</span>
                <span class="label">Heimbilanz:</span><span class="val">${game.homeRecord.wins}S ${game.homeRecord.draws}U ${game.homeRecord.losses}N</span>
                <span class="label">Auswärtsbilanz:</span><span class="val">${game.awayRecord.wins}S ${game.awayRecord.draws}U ${game.awayRecord.losses}N</span>
                <span class="label">Auswärts-Spitzname:</span><span class="val">${getAwayFormTitle()}</span>
                <span class="label">Ultimaten (Vertrag/Verkauf/Ignoriert):</span><span class="val">${game.ultimatumHistory?.renewed || 0} / ${game.ultimatumHistory?.sold || 0} / ${game.ultimatumHistory?.ignored || 0}</span>
                <span class="label">Berater-Vermittlungen (vorab/im Modal):</span><span class="val">${game.ultimatumHistory?.agentPreEmpted || 0} / ${game.ultimatumHistory?.agentMediated || 0}</span>
            </div>
            ${(game.trophies || []).length > 0 ? `<div style="margin-top:8px; font-size:11px; color:var(--gold);">🏆 ${(game.trophies || []).join(' · ')}</div>` : ''}
        `;
        // Trainer-Interview-Historie: letzte Medien-Auftritte, um den eigenen "Medien-
        // Charakter" über die Karriere nachvollziehen zu können.
        let interviewBox = document.getElementById('interview-history-box');
        if (interviewBox) {
            let recent = (game.interviewHistory || []).slice(-5).reverse();
            interviewBox.innerHTML = recent.length === 0
                ? '<div class="box" style="font-size:10px; color:#94a3b8;">Noch keine Interviews gegeben.</div>'
                : recent.map(h => `<div class="box" style="font-size:10px;"><span style="color:#94a3b8;">S${h.season}/${h.matchday}:</span> „${h.question}“ → <strong>${h.answer}</strong> <span style="color:${h.fans >= 0 ? 'var(--primary)' : 'var(--danger)'};">(Fans ${h.fans >= 0 ? '+' : ''}${h.fans})</span></div>`).join('');
        }
    }

    // Bewusst OHNE window.confirm() (kann in Dateimanager-WebViews unterdrückt werden, siehe
    // startNewGame()) - stattdessen dialogfreie Zwei-Klick-Bestätigung direkt am Button.
    // Anders als getSacked() wird HIER die Karriere NICHT übernommen - der Ruhestand ist ein
    // bewusster, vollständiger Neuanfang.
    function retireCareer() {
        let btn = document.getElementById('btn-retire');
        if (btn && btn.dataset.confirming !== 'true') {
            btn.dataset.confirming = 'true';
            btn.innerText = '⚠️ Wirklich? Komplette Karriere endet! Nochmal tippen zum Bestätigen';
            setTimeout(() => { if (btn) { btn.dataset.confirming = 'false'; btn.innerText = '🚪 In den Ruhestand gehen (neue Karriere beginnen)'; } }, 4000);
            return;
        }
        btn.dataset.confirming = 'false';
        btn.innerText = '🚪 In den Ruhestand gehen (neue Karriere beginnen)';
        showCareerCertificate();
    }

    // Karriere-Urkunde: fasst Trophäen-Zeitstrahl, Wappen-Historie und Kennzahlen der
    // beendeten Karriere in einer Übersicht zusammen, bevor der Ruhestand endgültig
    // vollzogen wird - als Erinnerung, da nach dem Neustart alles zurückgesetzt wird.
    function showCareerCertificate() {
        let trophyLines = (game.trophies || []).length > 0
            ? game.trophies.map((t, i) => `<div style="font-size:10px; margin:2px 0;">#${i + 1} · ${t}</div>`).join('')
            : '<div style="font-size:10px; color:#94a3b8;">Keine Trophäen errungen.</div>';

        let crestThumbs = crestHistory.slice(-8).map(c => {
            return `<div style="width:32px; height:32px; border-radius:50%; display:inline-flex; align-items:center; justify-content:center; font-size:13px; font-weight:900; color:#1a1200; border:1px solid rgba(255,255,255,0.5); margin:2px; background:radial-gradient(circle at 35% 30%, ${hexToRgba(c.color, 0.65)} 0%, ${c.color} 55%, ${hexToRgba(c.color, 0.75)} 100%);">${c.symbol}</div>`;
        }).join('');

        document.getElementById('career-certificate-content').innerHTML = `
            <div style="text-align:center; margin-bottom:12px;">
                <div style="font-size:16px; font-weight:900; color:var(--gold);">🏆 KARRIERE-URKUNDE 🏆</div>
                <div style="font-size:11px; color:#94a3b8;">${game.season} Saison(en) als Manager von ${game.clubName}</div>
            </div>
            <div class="modal-field-grid">
                <span class="label">Höchstes Manager-Level:</span><span class="val">${managerRPG.level} (${managerRPG.xp} XP)</span>
                <span class="label">Höchste erreichte Liga:</span><span class="val">${leagueNames[game.leagueLevel]}</span>
                <span class="label">Trophäen gesamt:</span><span class="val">${(game.trophies || []).length}</span>
                <span class="label">Derby-Bilanz:</span><span class="val">${rivalryRecord.wins}S ${rivalryRecord.draws}U ${rivalryRecord.losses}N</span>
                <span class="label">Schon entlassen:</span><span class="val">${game.timesSacked || 0}×</span>
                <span class="label">Legenden-Status:</span><span class="val">${game.legendStatus ? '👑 Ja' : 'Nein'}</span>
                <span class="label">Zuschauerrekord:</span><span class="val">${game.recordAttendance > 0 ? `${game.recordAttendance.toLocaleString('de-DE')} (Saison ${game.recordAttendanceSeason})` : '-'}</span>
                <span class="label">Ultimaten gelöst (V/Vk/I):</span><span class="val">${game.ultimatumHistory?.renewed || 0} / ${game.ultimatumHistory?.sold || 0} / ${game.ultimatumHistory?.ignored || 0}</span>
            </div>
            <div style="font-size:11px; font-weight:800; color:var(--accent); margin-top:10px;">Trophäen-Zeitstrahl</div>
            ${trophyLines}
            <div style="font-size:11px; font-weight:800; color:var(--accent); margin-top:10px;">Wappen-Historie</div>
            <div>${crestThumbs || '<div style="font-size:10px; color:#94a3b8;">Keine früheren Wappen-Designs.</div>'}</div>
            <div style="font-size:9px; color:#64748b; margin-top:10px; text-align:center;">📸 Lade dir die Urkunde als Bild herunter oder mach einen Screenshot - nach Bestätigung ist die Karriere unwiderruflich beendet!</div>
        `;
        document.getElementById('career-certificate-overlay').classList.add('show');
    }
    function closeCareerCertificate() {
        document.getElementById('career-certificate-overlay').classList.remove('show');
    }

    // Rendert die Karriere-Urkunde als PNG-Bild via Canvas und löst einen Download aus -
    // funktioniert komplett offline im Browser, ohne Server-Roundtrip.
    function exportCareerCertificateAsImage() {
        let canvas = document.createElement('canvas');
        canvas.width = 800;
        canvas.height = 1100;
        let ctx = canvas.getContext('2d');

        // Hintergrund
        let bgGradient = ctx.createLinearGradient(0, 0, 0, canvas.height);
        bgGradient.addColorStop(0, '#1a2138');
        bgGradient.addColorStop(1, '#0a0e1c');
        ctx.fillStyle = bgGradient;
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        ctx.strokeStyle = '#f5b942';
        ctx.lineWidth = 6;
        ctx.strokeRect(20, 20, canvas.width - 40, canvas.height - 40);

        ctx.textAlign = 'center';
        ctx.fillStyle = '#f5b942';
        ctx.font = 'bold 42px Arial';
        ctx.fillText('🏆 KARRIERE-URKUNDE 🏆', canvas.width / 2, 100);
        ctx.fillStyle = '#94a3b8';
        ctx.font = '20px Arial';
        ctx.fillText(`${game.season} Saison(en) als Manager von ${game.clubName}`, canvas.width / 2, 140);

        let y = 210;
        const line = (label, value, color = '#ffffff') => {
            ctx.textAlign = 'left';
            ctx.fillStyle = '#94a3b8';
            ctx.font = '18px Arial';
            ctx.fillText(label, 60, y);
            ctx.textAlign = 'right';
            ctx.fillStyle = color;
            ctx.font = 'bold 18px Arial';
            ctx.fillText(value, canvas.width - 60, y);
            y += 36;
        };
        line('Höchstes Manager-Level:', `${managerRPG.level} (${managerRPG.xp} XP)`, '#22e0a8');
        line('Höchste erreichte Liga:', leagueNames[game.leagueLevel], '#22e0a8');
        line('Trophäen gesamt:', String((game.trophies || []).length), '#22e0a8');
        line('Derby-Bilanz:', `${rivalryRecord.wins}S ${rivalryRecord.draws}U ${rivalryRecord.losses}N`, '#22e0a8');
        line('Zuschauerrekord:', game.recordAttendance > 0 ? game.recordAttendance.toLocaleString('de-DE') : '-', '#3fb6ff');
        line('Legenden-Status:', game.legendStatus ? '👑 Ja' : 'Nein', '#f5b942');
        line('Ultimaten (V/Vk/I):', `${game.ultimatumHistory?.renewed || 0} / ${game.ultimatumHistory?.sold || 0} / ${game.ultimatumHistory?.ignored || 0}`, '#ff8a5c');

        y += 20;
        ctx.textAlign = 'left';
        ctx.fillStyle = '#f5b942';
        ctx.font = 'bold 22px Arial';
        ctx.fillText('Trophäen-Zeitstrahl', 60, y);
        y += 34;
        ctx.font = '16px Arial';
        ctx.fillStyle = '#ffffff';
        let trophies = game.trophies || [];
        if (trophies.length === 0) {
            ctx.fillStyle = '#94a3b8';
            ctx.fillText('Keine Trophäen errungen.', 60, y);
            y += 28;
        } else {
            trophies.slice(0, 12).forEach((t, i) => {
                ctx.fillStyle = '#ffffff';
                ctx.fillText(`#${i + 1} · ${t}`, 60, y);
                y += 28;
            });
        }

        // Wappen-Vorschau unten
        y += 20;
        let crestColor = game.clubCrestColor || '#f5b942';
        ctx.beginPath();
        ctx.arc(canvas.width / 2, y + 60, 55, 0, Math.PI * 2);
        ctx.fillStyle = crestColor;
        ctx.fill();
        ctx.strokeStyle = '#ffffff';
        ctx.lineWidth = 3;
        ctx.stroke();
        ctx.textAlign = 'center';
        ctx.fillStyle = '#1a1200';
        ctx.font = 'bold 32px Arial';
        ctx.fillText(game.clubCrestSymbol || 'FCM', canvas.width / 2, y + 72);

        // Wappen-Historie als kleine Zeitleiste unter dem aktuellen Wappen.
        if (crestHistory.length > 0) {
            y += 140;
            ctx.textAlign = 'left';
            ctx.fillStyle = '#f5b942';
            ctx.font = 'bold 16px Arial';
            ctx.fillText('Wappen-Historie', 60, y);
            y += 30;
            let thumbs = crestHistory.slice(-8);
            let spacing = Math.min(80, (canvas.width - 120) / thumbs.length);
            let startX = canvas.width / 2 - (thumbs.length * spacing) / 2 + spacing / 2;
            thumbs.forEach((c, i) => {
                let cx = startX + i * spacing;
                ctx.beginPath();
                ctx.arc(cx, y + 22, 22, 0, Math.PI * 2);
                ctx.fillStyle = c.color;
                ctx.fill();
                ctx.strokeStyle = 'rgba(255,255,255,0.7)';
                ctx.lineWidth = 2;
                ctx.stroke();
                ctx.textAlign = 'center';
                ctx.fillStyle = '#1a1200';
                ctx.font = 'bold 14px Arial';
                ctx.fillText(c.symbol, cx, y + 27);
                ctx.fillStyle = '#94a3b8';
                ctx.font = '9px Arial';
                ctx.fillText(`S${c.season}`, cx, y + 52);
            });
            y += 60;
        }

        ctx.fillStyle = '#64748b';
        ctx.font = '12px Arial';
        ctx.fillText('Erstellt mit Anstoß Mobile Pro - FM13', canvas.width / 2, canvas.height - 30);

        let link = document.createElement('a');
        link.download = `Karriere-Urkunde-${game.clubCrestSymbol || 'LokLeipzig'}-Saison${game.season}.png`;
        link.href = canvas.toDataURL('image/png');
        link.click();
        showToast('📸 Karriere-Urkunde als Bild heruntergeladen!', 'success');
    }

    function confirmFinalRetirement() {
        safeSessionSet('anstoss_fm13_force_new_game', '1');
        location.reload();
    }

