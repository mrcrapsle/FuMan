
    function renderYouthView() {
        renderYouthLeagueTable();
        document.getElementById('youth-lvl-disp').innerText = game.youthAcademyLvl;
        let list = document.getElementById('youth-talents-list');
        list.innerHTML = '';
        let capacity = getYouthAcademyCapacity();
        let capBox = document.getElementById('youth-capacity-box');
        if (capBox) capBox.innerText = `Kapazität: ${youthTalents.length} / ${capacity}`;

        // Baustellen-Status: zeigt "im Bau..." statt des Kauf-Buttons, solange eine
        // Jugendakademie-/Kapazitäts-Baustelle läuft.
        let academyQueued = (game.stadiumConstructionQueue || []).find(q => q.type === 'youthAcademyLvl');
        let btnAcademy = document.getElementById('btn-upgrade-youth-academy');
        if (btnAcademy) {
            let cost = Math.max(300000, Math.round(600000 * Math.pow(game.youthAcademyLvl, 1.4) * (typeof getStadiumCostScale === 'function' ? getStadiumCostScale() : 1)));
            btnAcademy.innerText = academyQueued ? `🏗️ Im Bau... (noch ${academyQueued.daysLeft} SpT)` : `Akademie ausbauen [${formatVal(cost)}]`;
            btnAcademy.disabled = !!academyQueued;
        }
        let capacityQueued = (game.stadiumConstructionQueue || []).find(q => q.type === 'youthCapacity');
        let btnCapacity = document.getElementById('btn-expand-youth-capacity');
        if (btnCapacity) {
            let cost = Math.max(80000, Math.round(180000 * ((game.youthCapacityBonus || 0) + 1) * (typeof getStadiumCostScale === 'function' ? getStadiumCostScale() : 1)));
            btnCapacity.innerText = capacityQueued ? `🏗️ Im Bau... (noch ${capacityQueued.daysLeft} SpT)` : `🏠 Kapazität erweitern [${formatVal(cost)}]`;
            btnCapacity.disabled = !!capacityQueued;
        }

        youthTalents.forEach((p, idx) => {
            if (typeof ensureYouthPotential === 'function') ensureYouthPotential(p);
            let row = document.createElement('div');
            row.className = 'player-row';
            row.style.flexDirection = 'column';
            row.style.alignItems = 'stretch';
            let potentialHtml = p.potentialRevealed
                ? `<span class="badge" style="background:${POTENTIAL_TIER_COLORS[p.potentialTier]};">${POTENTIAL_TIER_LABELS[p.potentialTier]}</span>`
                : `<button onclick="revealYouthPotential('${p.id}')" class="btn-secondary" style="width:auto; font-size:8px;">🔍 Potenzial prüfen [3.000 €]</button>`;
            row.innerHTML = `
                <div style="display:flex; justify-content:space-between; align-items:center;">
                    <span style="display:flex; align-items:center; gap:6px;">${typeof renderPlayerAvatarTag === 'function' ? renderPlayerAvatarTag(p, 28) : ''}${p.name} (${p.pos}, ${p.age} J., Str ${p.strength})${p.proDecisionLeft ? ' <span class="badge" style="background:rgba(255,193,7,0.3);">✍️ Entscheidung</span>' : ''} ${p.trait && p.trait!=='Kein'?`<span class="badge badge-trait">${p.trait}</span>`:''}</span>
                    <span style="display:flex; gap:4px;">
                        <button onclick="promoteYouth(${idx}, this)" class="btn-action" style="width:auto; font-size:9px;">In Profikader</button>
                        ${(p.age || 0) >= 17 ? `<button onclick="openYouthLoanChoice('${p.id}')" class="btn-secondary" style="width:auto; font-size:9px;" title="Leihe zur Entwicklung">📤 Leihe</button>` : ''}
                        ${game.secondTeam.isActive ? `<button onclick="promoteYouthToSecondTeam(${idx}, this)" class="btn-secondary" style="width:auto; font-size:9px; color:var(--teal);" title="Behutsamer Weg: erst Spielpraxis in der Reserve sammeln">In die Reserve</button>` : ''}
                    </span>
                </div>
                <div style="display:flex; justify-content:space-between; align-items:center; margin-top:4px; font-size:9px;">
                    <span>${potentialHtml}</span>
                    <span>Fokus: <select class="input-inline" style="font-size:8px; padding:2px;" onchange="setYouthTrainingFocus('${p.id}', this.value)">
                        <option value="allgemein" ${p.youthFocus==='allgemein'?'selected':''}>Allgemein</option>
                        <option value="torschuss" ${p.youthFocus==='torschuss'?'selected':''}>Torschuss</option>
                        <option value="passspiel" ${p.youthFocus==='passspiel'?'selected':''}>Passspiel</option>
                        <option value="zweikampf" ${p.youthFocus==='zweikampf'?'selected':''}>Zweikampf</option>
                        <option value="tempo" ${p.youthFocus==='tempo'?'selected':''}>Tempo</option>
                    </select></span>
                    <button onclick="releaseYouthTalent('${p.id}', this)" class="btn-secondary" style="width:auto; font-size:8px; color:var(--danger);">Freilassen</button>
                </div>
                <div style="margin-top:4px; font-size:9px;">
                    🎓 Mentor: <select class="input-inline" style="font-size:8px; padding:2px;" onchange="this.value ? assignYouthMentor('${p.id}', this.value) : removeYouthMentor('${p.id}')">
                        <option value="">Kein Mentor</option>
                        ${squad.filter(s => s.age >= 27 && s.strength >= 55).map(s => `<option value="${s.id}" ${p.mentorId===s.id?'selected':''}>${s.name} (${s.age} J., Str ${s.strength})</option>`).join('')}
                    </select>
                    ${p.mentorId && squad.some(s=>s.id===p.mentorId) ? '<span style="color:var(--primary);"> +35% Entwicklungstempo während Hospitanz</span>' : ''}
                </div>
            `;
            list.appendChild(row);
        });

        let poachBox = document.getElementById('youth-poach-box');
        if (poachBox) {
            let pend = game.pendingYouthPoach;
            poachBox.style.display = pend ? 'block' : 'none';
            if (pend) {
                poachBox.innerHTML = `<div class="panel-header" style="color:var(--danger);">🎯 ABWERBEVERSUCH: ${pend.name}</div>
                    <div class="box" style="font-size:10px;">Ein Rivale will ${pend.name} abwerben! Ablösesumme zahlen (${formatVal(pend.retentionCost)}) oder ziehen lassen?</div>
                    <div style="display:grid; grid-template-columns:1fr 1fr; gap:4px;">
                        <button onclick="resolveYouthPoaching(true)" class="btn-action">💰 Halten</button>
                        <button onclick="resolveYouthPoaching(false)" class="btn-secondary">👋 Ziehen lassen</button>
                    </div>`;
            }
        }
        if (typeof renderYouthPathwayBoxes === 'function') renderYouthPathwayBoxes();

        if (typeof renderYouthAcademyPanel === 'function') renderYouthAcademyPanel();
        if (typeof renderYouthDevelopmentChart === 'function') renderYouthDevelopmentChart();
        if (typeof migrateLegacyYouthAcademy === 'function') migrateLegacyYouthAcademy();
        if (typeof renderAcademyRankingPanel === 'function') renderAcademyRankingPanel();
    }

    // ==========================================
    // JUGENDAKADEMIE: NEUE FUNKTIONEN
    // ==========================================
    const POTENTIAL_TIER_LABELS = { 1: '⭐ Mittelmaß', 2: '⭐⭐ Vielversprechend', 3: '⭐⭐⭐ Ausnahmetalent' };
    const POTENTIAL_TIER_COLORS = { 1: 'rgba(228,197,140,0.2)', 2: 'rgba(76,175,122,0.3)', 3: 'rgba(212,169,74,0.4)' };

    // 1. Jugendkader-Kapazität: skaliert mit Akademie-Stufe, zusätzlich ausbaubar.
    function getYouthAcademyCapacity() {
        // Bugfix: bisher nur 3+2×Stufe Plätze (z.B. 5 bei Stufe 1) - viel zu wenig, um wie die
        // Zweite Mannschaft eine vollständige Elf plus Bank für echte Jugendliga-Spiele zu
        // stellen. Jetzt eine realistische Kadergröße ab Start.
        return 14 + game.youthAcademyLvl * 2 + (game.youthCapacityBonus || 0);
    }
    function expandYouthCapacity() {
        let cost = Math.max(80000, Math.round(180000 * ((game.youthCapacityBonus || 0) + 1) * getStadiumCostScale()));
        // Bugfix: ließ sich bisher komplett ohne Wartezeit sofort ausbauen - jetzt über
        // dieselbe Baustellen-Logik wie Stadion/Campus mit echter Bauzeit.
        if (typeof queueStadiumConstruction === 'function') {
            queueStadiumConstruction('youthCapacity', {}, cost, getConstructionDays(cost), 'Jugendkader-Kapazität erweitern');
            return;
        }
        playSound('goal');
        game.money -= cost;
        game.youthCapacityBonus = (game.youthCapacityBonus || 0) + 1;
        showToast(`🏠 Jugendkader-Kapazität erweitert auf ${getYouthAcademyCapacity()} Plätze!`, 'success');
        renderYouthView();
        updateUI();
    }

    // 2. Potenzial-Anzeige: verstecktes Entwicklungspotenzial, gegen Bezahlung aufdeckbar,
    // beeinflusst wie stark ein Talent von Hospitanz/Training profitiert.
    function assignYouthPotentialTier(p) {
        // Jugendinternat (Bugfix, NEU): jede Ausbaustufe verschiebt die Wahrscheinlichkeit
        // spürbar zu höheren Potenzial-Stufen - die beworbene Wirkung war bisher komplett
        // unverkabelt.
        let internatLvl = campusBuildings.internat?.lvl || 0;
        let roll = Math.random() + internatLvl * 0.06;
        p.potentialTier = roll < 0.6 ? 1 : (roll < 0.9 ? 2 : 3);
        p.potentialRevealed = false;
    }
    function revealYouthPotential(playerId) {
        let p = youthTalents.find(y => y.id === playerId);
        if (!p || p.potentialRevealed) return;
        let cost = 3000;
        if (game.money < cost) { showToast(`Nicht genug Geld! Benötigt: ${formatVal(cost)}`, 'error'); return; }
        playSound('click');
        game.money -= cost;
        p.potentialRevealed = true;
        showToast(`🔍 Potenzial von ${p.name}: ${POTENTIAL_TIER_LABELS[p.potentialTier]}`, 'success');
        renderYouthView();
        updateUI();
    }
    function getYouthPotentialMultiplier(p) {
        if (!p) return 1;
        return { 1: 0.8, 2: 1.2, 3: 1.8 }[p.potentialTier] || 1;
    }

    // 3. Jugend-Ausbildungsschwerpunkt: individueller Trainingsfokus wie bei Profis, wirkt
    // sich in der Hospitanz-Entwicklung aus (siehe Hook in match.js).
    function setYouthTrainingFocus(playerId, focus) {
        let p = youthTalents.find(y => y.id === playerId);
        if (p) { p.youthFocus = focus; renderYouthView(); }
    }

    // ==========================================
    // JUGENDLIGA-TABELLE
    // ==========================================
    // Bisher gab es nur ein einmaliges "Jugendturnier"-Ereignis ohne jeden Wettbewerbs-
    // kontext. Jetzt eine echte Liga mit 7 KI-Nachwuchsakademien, gegen die automatisch
    // gespielt wird - mit Tabelle, Saisonverlauf und einer echten Belohnung für eine gute
    // Platzierung am Saisonende.
    const YOUTH_RIVAL_NAMES = ['SC Jugendblitz', 'FC Talentschmiede', 'TuS Nachwuchs 08', 'SV Perspektive', 'Grün-Weiß Youngstars', '1. FC Zukunft', 'Rasenkicker U19'];
    function initYouthLeagueTable() {
        youthLeagueTable = [
            { name: `${game.clubName} (Jugend)`, isOwn: true, played: 0, won: 0, drawn: 0, lost: 0, points: 0, goalsFor: 0, goalsAgainst: 0 },
            ...YOUTH_RIVAL_NAMES.map(n => ({ name: n, isOwn: false, played: 0, won: 0, drawn: 0, lost: 0, points: 0, goalsFor: 0, goalsAgainst: 0, strength: 45 + Math.floor(Math.random() * 25) }))
        ];
        youthLeagueMatchday = 0;
    }
    function getOwnYouthAcademyStrength() {
        if (youthTalents.length === 0) return 40;
        let topFive = [...youthTalents].sort((a, b) => b.strength - a.strength).slice(0, 5);
        return Math.round(topFive.reduce((s, p) => s + p.strength, 0) / topFive.length);
    }
    // Wird alle 4 Spieltage automatisch ausgetragen (siehe periodischer Hook in match.js):
    // simuliert EIN Jugendliga-Spiel unseres Teams gegen einen zufälligen Rivalen, plus die
    // übrigen Rivalen-Paarungen untereinander, damit die Tabelle realistisch wächst.
    function tickYouthLeague() {
        if (!youthLeagueTable || youthLeagueTable.length === 0) initYouthLeagueTable();
        if (youthLeagueMatchday >= 26) return; // Jugendliga-Saison beendet, wartet auf Reset
        youthLeagueMatchday++;
        let ownTeam = youthLeagueTable.find(t => t.isOwn);
        let rivals = youthLeagueTable.filter(t => !t.isOwn);
        let opponent = rivals[Math.floor(Math.random() * rivals.length)];
        let ownStr = getOwnYouthAcademyStrength();
        simulateYouthMatch(ownTeam, opponent, ownStr, opponent.strength);
        // Ein paar Rivalen-Paarungen untereinander, damit die Tabelle nicht nur um uns kreist.
        for (let i = 0; i < 2; i++) {
            let a = rivals[Math.floor(Math.random() * rivals.length)];
            let b = rivals[Math.floor(Math.random() * rivals.length)];
            if (a !== b && a !== opponent && b !== opponent) simulateYouthMatch(a, b, a.strength, b.strength);
        }
        if (youthLeagueMatchday === 26) concludeYouthLeagueSeason();
    }
    function simulateYouthMatch(teamA, teamB, strA, strB) {
        let diff = strA - strB;
        let goalsA = Math.max(0, Math.round(1 + diff * 0.04 + (Math.random() * 3 - 1)));
        let goalsB = Math.max(0, Math.round(1 - diff * 0.04 + (Math.random() * 3 - 1)));
        teamA.played++; teamB.played++;
        teamA.goalsFor += goalsA; teamA.goalsAgainst += goalsB;
        teamB.goalsFor += goalsB; teamB.goalsAgainst += goalsA;
        if (goalsA > goalsB) { teamA.won++; teamA.points += 3; teamB.lost++; }
        else if (goalsA < goalsB) { teamB.won++; teamB.points += 3; teamA.lost++; }
        else { teamA.drawn++; teamB.drawn++; teamA.points++; teamB.points++; }
    }
    function concludeYouthLeagueSeason() {
        let sorted = [...youthLeagueTable].sort(compareTableRows);
        let ourRank = sorted.findIndex(t => t.isOwn) + 1;
        let scale = typeof leagueScaleFactor === 'function' ? leagueScaleFactor() : 1;
        if (ourRank === 1) {
            let bonus = Math.round(15000 * scale);
            game.money += bonus;
            if (typeof boostFanBaseFloor === 'function') boostFanBaseFloor(2, 'Der Meistertitel der Jugendliga');
            addInboxMessage('vertrag', '🏆 Jugendliga-Meister!', `Die Nachwuchsakademie wird Meister der Jugendliga! Bonus: ${formatVal(bonus)}, dazu dauerhaft mehr Fan-Interesse.`, 'screen-youth');
        } else if (ourRank <= 3) {
            let bonus = Math.round(6000 * scale);
            game.money += bonus;
            addInboxMessage('vertrag', `🥉 Jugendliga: Platz ${ourRank}!`, `Eine starke Saison der Nachwuchsakademie (Platz ${ourRank}) bringt ${formatVal(bonus)} Prämie.`, 'screen-youth');
        } else {
            addInboxMessage('vertrag', `📋 Jugendliga beendet: Platz ${ourRank}`, `Die Nachwuchsakademie beendet die Saison auf Platz ${ourRank} von ${youthLeagueTable.length}.`, 'screen-youth');
        }
        initYouthLeagueTable();
    }
    function renderYouthLeagueTable() {
        let box = document.getElementById('youth-league-table-box');
        if (!box) return;
        if (!youthLeagueTable || youthLeagueTable.length === 0) initYouthLeagueTable();
        let sorted = [...youthLeagueTable].sort(compareTableRows);
        box.innerHTML = `
            <table><thead><tr><th>Pl</th><th>Team</th><th>Sp</th><th>Tore</th><th>Pkt</th></tr></thead><tbody>
            ${sorted.map((t, i) => `<tr style="${t.isOwn ? 'font-weight:900; color:var(--accent);' : ''}"><td>${i+1}</td><td style="text-align:left;">${t.name}</td><td>${t.played}</td><td>${t.goalsFor}:${t.goalsAgainst}</td><td>${t.points}</td></tr>`).join('')}
            </tbody></table>
            <div style="font-size:8px; color:var(--text-muted); margin-top:4px;">Spieltag ${youthLeagueMatchday}/26 · nächstes Spiel automatisch alle 4 Spieltage</div>
        `;
    }

    // ==========================================
    // JUGEND-MENTOR-SYSTEM
    // ==========================================
    // Ein erfahrener Profi (27+ Jahre, Stärke 55+) übernimmt die persönliche Betreuung eines
    // Jugendtalents während der Hospitanz - beschleunigt dessen Entwicklung spürbar (+35%
    // Wachstumschance). Ein Mentor kann immer nur EIN Talent gleichzeitig betreuen, damit die
    // Wahl echte Bedeutung hat statt einfach alle Talente gleichzeitig zu boosten.
    function assignYouthMentor(youthId, mentorId) {
        let youth = youthTalents.find(y => y.id === youthId);
        let mentor = squad.find(s => s.id === mentorId);
        if (!youth || !mentor) return;
        if (mentor.age < 27 || mentor.strength < 55) { showToast('Der Mentor muss mindestens 27 Jahre alt und Stärke 55+ haben!', 'error'); return; }
        if (youthTalents.some(y => y.mentorId === mentorId)) { showToast(`${mentor.name} betreut bereits ein anderes Talent!`, 'error'); return; }
        youth.mentorId = mentorId;
        showToast(`🎓 ${mentor.name} übernimmt die Mentorenschaft für ${youth.name}!`, 'success');
        renderYouthView();
    }
    function removeYouthMentor(youthId) {
        let youth = youthTalents.find(y => y.id === youthId);
        if (!youth) return;
        youth.mentorId = null;
        renderYouthView();
    }

    // 4. Abwerbeversuche von Rivalen: Zufallsereignis, Ablöse zahlen oder verlieren.
    function checkYouthPoachingAttempt() {
        if (youthTalents.length === 0 || game.pendingYouthPoach) return;
        if (Math.random() > 0.015) return;
        let p = youthTalents[Math.floor(Math.random() * youthTalents.length)];
        let retentionCost = Math.round(calculatePlayerMarketValue(p.strength) * 0.4) + 5000;
        game.pendingYouthPoach = { playerId: p.id, name: p.name, retentionCost };
        addInboxMessage('vertrag', `🎯 Abwerbeversuch: ${p.name}!`, `Ein Rivale will Nachwuchstalent ${p.name} abwerben. Zahle ${formatVal(retentionCost)}, um ihn zu halten (Jugendakademie-Screen), sonst wechselt er den Verein!`, 'screen-youth');
    }
    function resolveYouthPoaching(pay) {
        let pend = game.pendingYouthPoach;
        if (!pend) return;
        if (pay) {
            if (game.money < pend.retentionCost) { showToast('Nicht genug Geld!', 'error'); return; }
            game.money -= pend.retentionCost;
            showToast(`✅ ${pend.name} bleibt in der Akademie!`, 'success');
        } else {
            youthTalents = youthTalents.filter(p => p.id !== pend.playerId);
            showToast(`😢 ${pend.name} hat die Akademie verlassen.`, 'error');
        }
        game.pendingYouthPoach = null;
        renderYouthView();
        updateUI();
    }

    // 5. Jugend-Nationalmannschaft-Berufung: seltenes Prestige-Ereignis für starke Talente.
    function checkYouthNationalCallup() {
        let eligible = youthTalents.filter(p => p.strength >= 62);
        if (eligible.length === 0 || Math.random() > 0.01) return;
        let p = eligible[Math.floor(Math.random() * eligible.length)];
        p.strength = Math.min(99, p.strength + 1);
        game.fans = Math.min(100, game.fans + 2);
        addInboxMessage('vertrag', `🌍 U-Nationalmannschaft: ${p.name} berufen!`, `${p.name} wird erstmals in eine deutsche Jugend-Nationalmannschaft berufen - eine große Ehre für die Akademie und einen echten Entwicklungsschub!`, 'screen-youth');
    }

    // 6. Jugendturnier: einmaliges Event, kleine Chance auf Bonus-Entwicklung für alle Talente.
    function holdYouthTournament() {
        if (youthTalents.length === 0) { showToast('Keine Jugendspieler vorhanden!', 'error'); return; }
        let cost = 4000;
        if (game.money < cost) { showToast(`Nicht genug Geld! Benötigt: ${formatVal(cost)}`, 'error'); return; }
        playSound('goal');
        game.money -= cost;
        let improved = [];
        youthTalents.forEach(p => {
            if (Math.random() < 0.2 * getYouthPotentialMultiplier(p)) { p.strength = Math.min(99, p.strength + 1); improved.push(p.name); }
        });
        if (improved.length >= 2 && typeof updateAcademyPoints === 'function') updateAcademyPoints('youth-tournament-win');
        showToast(improved.length > 0 ? `🏆 Jugendturnier: ${improved.join(', ')} zeigten starke Leistungen!` : '🏆 Jugendturnier durchgeführt - keine besonderen Ausreißer.', 'success');
        renderYouthView();
        updateUI();
    }

    // 8. Jugendtalent freilassen: bisher gab es nur "Befördern", kein Ausmustern.
    function releaseYouthTalent(playerId, btn) {
        if (!requireConfirm(btn, 'Wirklich freilassen?')) return;
        let p = youthTalents.find(y => y.id === playerId);
        if (!p) return;
        youthTalents = youthTalents.filter(y => y.id !== playerId);
        game.youthHospitants = (game.youthHospitants || []).filter(id => id !== playerId);
        showToast(`👋 ${p.name} wurde aus der Jugendakademie entlassen.`, 'success');
        renderYouthView();
    }

    function upgradeYouthAcademy() {
        // Preis-Korrektur: 35.000 € je Stufe war für eine Jugendakademie grotesk niedrig -
        // billiger als der Foodtruck-Garten (550.000 €), obwohl sie den gesamten Nachwuchs
        // trägt. Jetzt auf dem Niveau der großen Campus-Bauten (Internat 5,5 Mio,
        // Reha-Zentrum 4,5 Mio) und mit jeder Stufe deutlich teurer.
        let cost = Math.max(300000, Math.round(600000 * Math.pow(game.youthAcademyLvl, 1.4) * getStadiumCostScale()));
        // Kein stummes Abbrechen mehr: die Deckungsprüfung macht queueStadiumConstruction
        // mit einer klaren Meldung (vorher wurde hier wortlos zurückgesprungen).
        // Bugfix: ließ sich bisher komplett ohne Wartezeit sofort ausbauen - jetzt mit
        // echter Bauzeit über dieselbe Baustellen-Logik wie Stadion/Campus.
        if (typeof queueStadiumConstruction === 'function') {
            queueStadiumConstruction('youthAcademyLvl', {}, cost, getConstructionDays(cost), `Jugendakademie auf Stufe ${game.youthAcademyLvl + 1}`);
            return;
        }
        playSound('click');
        game.money -= cost;
        game.youthAcademyLvl++;
        renderYouthView();
        updateUI();
    }

    function scoutYouthTalent() {
        if (youthTalents.length >= getYouthAcademyCapacity()) { showToast('Jugendkader-Kapazität erreicht! Erst ausbauen oder Plätze freimachen.', 'error'); return; }
        if (game.money < 8000) { showToast(`Nicht genug Geld! Benötigt: ${formatVal(8000)}`, 'error'); return; }
        playSound('click');
        game.money -= 8000;
        // Bugfix: das Jugendinternat bewarb "erhöht Stärke und Potenzial neuer
        // Nachwuchsspieler", wirkte sich aber bisher NUR auf eine DFB-Lizenz-Anforderung aus -
        // die eigentliche Stärke-/Potenzial-Verbesserung war nie verkabelt.
        let internatLvl = campusBuildings.internat?.lvl || 0;
        let p = createPlayer(["TW", "ABW", "MIT", "ST"][Math.floor(Math.random()*4)], 46 + game.youthAcademyLvl * 3 + internatLvl * 2, 58 + game.youthAcademyLvl * 3 + internatLvl * 2, null, [15, 18]);
        assignYouthPotentialTier(p);
        if (typeof ensureYouthPotential === 'function') ensureYouthPotential(p);
        p.youthFocus = 'allgemein';
        youthTalents.push(p);
        renderYouthView();
        updateUI();
    }

    // Der behutsame Weg: statt direkt in den Profikader zuerst in die zweite Mannschaft,
    // wo der Spieler echte Spielpraxis bekommt und sich (mit Nachwuchs-Koordinator) weiter
    // entwickelt, ohne einen Profi-Kaderplatz zu belegen.
    function promoteYouthToSecondTeam(idx, btn) {
        if (!game.secondTeam.isActive) { showToast('Dafür muss erst eine zweite Mannschaft gegründet sein.', 'error', 4000); return; }
        if (!requireConfirm(btn, 'Wirklich in die Reserve?')) return;
        playSound('click');
        let p = youthTalents[idx];
        p.academyGraduate = true;
        p.proDecisionLeft = null;
        secondTeamSquad.push(p);
        youthTalents.splice(idx, 1);
        if (typeof autoLineupSecondTeam === 'function') autoLineupSecondTeam();
        addInboxMessage('vertrag', `🅱️ ${p.name} rückt in die Reserve auf`, `${p.name} (${p.pos}, Stärke ${p.strength}) sammelt ab sofort Spielpraxis bei ${game.secondTeam.name}, statt sofort im Profikader zu sitzen.`, 'screen-second-team');
        showToast(`🅱️ ${p.name} in die zweite Mannschaft befördert!`, 'success');
        renderYouthView();
        updateUI();
    }

    function promoteYouth(idx, btn) {
        // Hochziehen belegt dauerhaft einen Kaderplatz und kostet Gehalt - nicht ohne Rückfrage.
        if (!requireConfirm(btn, 'Wirklich hochziehen?')) return;
        playSound('click');
        let p = youthTalents[idx];
        if (typeof signYouthProContract === 'function') signYouthProContract(p);
        squad.push(p);
        youthTalents.splice(idx, 1);
        if (typeof updateAcademyPoints === 'function') updateAcademyPoints('youth-graduation');
        // Jugendakademie-Abschlussfeier: statt nur einer trockenen Nachricht ein kleines
        // Zeremoniell mit Moralschub fürs ganze Team - ein Aufstieg aus der eigenen Jugend
        // ist immer ein Grund zum Feiern für die Kabine.
        squad.forEach(pl => { pl.morale = Math.min(100, pl.morale + 2); });
        game.fans = Math.min(100, game.fans + 2);
        addInboxMessage('vertrag', `🎓 Jugendakademie-Abschlussfeier: ${p.name}!`, `${p.name} (${p.pos}, Stärke ${p.strength}) unterschreibt einen Profivertrag über ${p.contracts} Jahre (${formatVal(p.wage)} pro Spieltag) und wird feierlich in den Profikader aufgenommen - die ganze Mannschaft feiert mit!`, 'screen-squad');
        showToast(`🎓 ${p.name} feierlich in den Profikader befördert!`, 'success');
        renderYouthView();
        updateUI();
    }

